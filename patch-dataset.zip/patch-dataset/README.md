# Patch Dataset 

Hsueh-Ti Derek Liu, Alec Jacobson, Keenan Crane

This directory contains 100 meshes stored as .obj files. Each set of 10 contains
"geometric textures" of the same category.

Cite this dataset using the following bibtex:

```
@article{Liu:Dirac:2017,
  title = {A Dirac Operator for Extrinsic Shape Analysis},
  author = {Hsueh-Ti Derek Liu, Alec Jacobson, Keenan Crane},
  year = {2017},
  journal = {Computer Graphics Forum}, 
}
```

© Derek Liu 2017.
